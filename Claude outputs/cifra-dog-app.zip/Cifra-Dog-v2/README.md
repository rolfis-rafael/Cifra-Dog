# Cifra-Dog v2

App de cifras sem PHP: funciona offline, no celular e no computador. Pode ser instalado como programa (PWA).

## Rodar no computador
- Pelo XAMPP (só o Apache, sem MySQL): abra `http://localhost/Cifra-Dog-main/v2/`
- No Chrome ou Edge, clique no ícone **Instalar** da barra de endereço. O Cifra-Dog vira um programa com janela própria e aparece no menu Iniciar.

## Rodar no celular
1. Suba a pasta `v2` no Netlify: arraste a pasta em app.netlify.com/drop.
2. Abra o link no Chrome do celular → menu ⋮ → **Instalar app**.
3. Depois de instalado, funciona sem internet.

> As cifras ficam salvas **no aparelho** (IndexedDB). Para passar do PC para o celular, use **Sua Biblioteca → Backup → Exportar** e depois **Importar** no outro aparelho.

## Arquivos
| Arquivo | O que faz |
|---|---|
| `index.html` | Página única do app |
| `css/app.css` | Visual preto e vermelho; no PC ganha barra lateral |
| `js/cifra-motor.js` | Motor do Cifra-Dog original: transpor, acordes, diagramas, ChordPro |
| `js/db.js` | Banco local (substitui o MySQL/PHP) |
| `js/telas.js` | Telas: Início, Buscar, Biblioteca, Criar, Cifra, Repertório |
| `js/app.js` | Rotas, mini-player, instalar, backup |
| `js/exemplos.js` | Cifras de exemplo da primeira abertura |
| `js/rolagem-bpm.js` | Rolagem por BPM |
| `js/lista-video.js` | Lista de músicas do vídeo (sem cifra) |
| `js/controle.js` | Pedal MIDI / teclas: aprender botões, ações, rolagem pelo pedal |
| `sw.js` | Modo offline. Ao mudar algum arquivo, aumente a `VERSAO` |

## Mecânicas
- **Rolagem por BPM:** Ajustes da cifra → *Rolagem por BPM*. A cada tempo 1 do compasso desce uma frase, marcada com marca-texto leve. Opções: BPM, compassos por frase (padrão e por frase), clique sonoro. Toque numa frase para pular para ela; segure para mudar os compassos só dela. Lógica em `js/rolagem-bpm.js`.
  - Tempos por compasso: 4/4 = 4 · 3/4 = 3 · 2/4 = 2 · 7/4 = 7 · 6/8 = 2 · 12/8 = 4 (em 6/8 e 12/8 o BPM é o da semínima pontuada).
- **Substituir posição:** no ⋯ de uma música do repertório. Digite o nº ou escolha na lista, e as duas trocam de lugar. Arrastar pela alça também funciona.
- **Blocos:** botão *Dividir em bloco* (ou *Começar um bloco aqui* no ⋯ da música). Toque na faixa para renomear ou remover.

## Pedal (MIDI ou teclado) — ex.: M-VAVE Chocolate Plus
Menu do avatar (ou Ajustes da cifra) → **Configurações**.
- **MIDI:** ligue a chave (Chrome/Edge; precisa de https ou localhost). Toque em **+ Aprender** numa ação e pise no botão: vale PC, CC ou Nota.
- **Modo teclado** do pedal (Page Up/Down, setas, Espaço): não precisa ligar o MIDI, é só aprender.
- **Program Change sem botão definido** vai para a música nº (PC 0 = nº 1).
- **Rolagem pelo pedal:** o potenciômetro define quanto a tela anda a cada pisada (% da tela).
- Ações: próxima/anterior música, descer/subir/início da tela, rolagem, próxima/anterior frase (BPM), pesquisar no repertório, tom ±, tom original, letra ±, palco, curtir.

## Show no celular
Na cifra aberta pelo repertório: botões grandes de anterior/próxima, a próxima música aparece embaixo do nome, e tocar no nome abre a **lista do repertório com busca** (nome ou nº; Enter abre a primeira).

## Várias ordens no repertório
Linha **Ordem** no repertório: Ordem 1, + Nova (copiar a atual ou vazia) e ⋯ (organizar automaticamente, duplicar, renomear, excluir). **Organizar** ordena dentro de cada bloco por título, artista, tom, BPM, nº da lista, aleatória ou inverter — por padrão cria uma ordem nova. O modo show segue a ordem em uso.

## Backup celular ↔ PC
Exportar no aparelho de origem e Importar no outro. A importação **junta** pelo nome + artista (não duplica) e não apaga cifra já colada.

## Lista do vídeo
Na primeira abertura o app cria o repertório **Lista do vídeo** com as músicas da sua lista (sem duplicar), em 3 blocos, **sem as cifras**. Em *Sua Biblioteca → Sem cifra* elas aparecem em ordem; toque na música → *Abrir a cifra no site* → copie → *Colar a cifra*. Dados em `js/lista-video.js`.

## Atalhos no PC (tela da cifra)
Espaço = rolar/pausar · `+`/`-` = tom · ←/→ = música anterior/próxima no repertório · `P` = modo palco
