/*
 * sw.js — Service Worker: guarda os arquivos do app para funcionar OFFLINE.
 * AJUSTAR: sempre que mudar algum arquivo, aumente a VERSAO para o celular baixar a nova.
 */
const PREFIXO = 'cifradog:' + self.registration.scope + ':';
const VERSAO = PREFIXO + '2.7.0';
const ARQUIVOS = [
    './', './index.html', './manifest.json', './css/app.css', './css/taverna.css',
    './js/cifra-motor.js', './js/db.js', './js/exemplos.js', './js/lista-video.js', './js/rolagem-bpm.js', './js/programada.js', './js/controle.js',
    './js/ui.js', './js/telas.js', './js/app.js',
    './img/logo.png', './img/jornal.svg', './img/dog.png', './img/icon-192.png', './img/icon-512.png',
    './img/icon-maskable.png', './img/apple-touch-icon.png',
    './img/taverna/pub-background.png', './img/taverna/covers-atlas.png', './img/taverna/materials-atlas.png',
    './img/taverna/pub-mobile.png',
];

self.addEventListener('install', (e) => {
    e.waitUntil(caches.open(VERSAO).then(c => c.addAll(ARQUIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
    e.waitUntil(
        caches.keys()
            .then(nomes => Promise.all(nomes.filter(n => n.startsWith(PREFIXO) && n !== VERSAO).map(n => caches.delete(n))))
            .then(() => self.clients.claim())
    );
});

/* Primeiro tenta o cache (rápido e offline); se não tiver, busca na rede. */
self.addEventListener('fetch', (e) => {
    if (e.request.method !== 'GET') return;
    e.respondWith(
        caches.open(VERSAO).then(c => c.match(e.request, { ignoreSearch: true })).then(r => r || fetch(e.request))
    );
});
