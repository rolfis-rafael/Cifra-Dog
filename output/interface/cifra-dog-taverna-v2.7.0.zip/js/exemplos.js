/*
 * exemplos.js — Cifras que vêm com o app na primeira vez que ele abre.
 * São músicas de domínio público / folclore e uma demo original do Cifra-Dog.
 * Depois você pode apagar e colocar as suas pelo botão "Criar".
 */
(function (global) {
    'use strict';

    const EXEMPLOS = [
        {
            titulo: 'Latido no Palco (demo)', artista: 'Cifra-Dog', tom: 'Am', bpm: 120, compasso: '4/4', curtida: true,
            cifra: `[Intro]
Am  F  C  G
E|-----------------|
B|-----1-----1-----|
G|---2-----2-------|
D|-2-----2---------|
A|0----------------|
E|-----------------|

[Verso]
Am                 F
Liguei o amplificador
C                    G
O cachorro já subiu no palco
Am                  F
Quatro cordas e um tambor
C                       G
E a cidade inteira no embalo

[Refrão]
F          G          Am
Late, late, late mais alto
F           G           C   E7
Que hoje a noite é de rock
F          G          Am
Late, late, late mais alto
F        G        Am
Cifra-Dog no palco`,
        },
        {
            titulo: 'Ciranda, Cirandinha', artista: 'Folclore brasileiro', tom: 'C', bpm: 100, compasso: '2/4',
            cifra: `[Refrão]
C                G7
Ciranda, cirandinha
                  C
Vamos todos cirandar
                    G7
Vamos dar a meia volta
                    C
Volta e meia vamos dar

[Verso]
C                   G7
O anel que tu me destes
                    C
Era vidro e se quebrou
                    G7
O amor que tu me tinhas
                    C
Era pouco e se acabou`,
        },
        {
            titulo: 'Peixe Vivo', artista: 'Folclore brasileiro', tom: 'D', bpm: 90, compasso: '4/4', curtida: true,
            cifra: `[Verso]
D                A7
Como pode o peixe vivo
                  D
Viver fora da água fria
D7          G
Como poderei viver
D           A7
Como poderei viver
             D       G
Sem a tua, sem a tua
A7          D
Sem a tua companhia`,
        },
        {
            titulo: 'Escravos de Jó', artista: 'Folclore brasileiro', tom: 'C', bpm: 110, compasso: '4/4',
            cifra: `[Verso]
C                     G7
Escravos de Jó jogavam caxangá
                     C
Tira, põe, deixa ficar
                          G7
Guerreiros com guerreiros fazem zigue zigue zá
                          C
Guerreiros com guerreiros fazem zigue zigue zá`,
        },
        {
            titulo: 'Amazing Grace', artista: 'John Newton (1779)', tom: 'G', bpm: 80, compasso: '3/4',
            cifra: `[Verso]
G           G7        C       G
Amazing grace, how sweet the sound
                      D
That saved a wretch like me
G            G7     C        G
I once was lost, but now am found
Em        D       G
Was blind, but now I see`,
        },
    ];

    /* Coloca os exemplos no banco só na primeira vez. */
    async function semearSePreciso() {
        if (await DB.lerMeta('semeado')) return;
        // Se a página foi recarregada no meio da primeira importação, não duplica o que já entrou.
        const ids = [];
        const jaTem = await DB.listarMusicas();
        let t = Date.now();
        for (const e of EXEMPLOS) {
            let m = jaTem.find(x => x.titulo === e.titulo && x.artista === e.artista);
            if (!m) m = await DB.salvarMusica(Object.assign({}, e, { abertaEm: t-- }));
            ids.push(m.id);
        }
        if (!(await DB.listarRepertorios()).some(r => r.nome === 'Ensaio de sábado')) {
            await DB.salvarRepertorio({
                nome: 'Ensaio de sábado', descricao: 'Repertório de exemplo',
                abertoEm: Date.now(),
                itens: [ids[0], ids[2], ids[1]].map(id => ({ id: DB.novoId(), tipo: 'musica', musicaId: id, semitons: 0 })),
            });
        }
        await DB.gravarMeta('semeado', true);
    }

    global.Exemplos = { semearSePreciso };
})(window);
